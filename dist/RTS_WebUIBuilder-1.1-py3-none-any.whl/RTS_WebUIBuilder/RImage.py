

class RImage:
    def __init__(self, image_path):
        self.image_path = image_path